Projeto Pega ID do Anúncio e da Variação
